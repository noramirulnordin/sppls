<div class="leftside-menu">

    <!-- LOGO -->
    <a href="/" class="logo text-center logo-light mt-1">
        <span class="logo-lg">
            <img src="/assets/images/logo-lg.png" alt="" height="55">
        </span>
        <span class="logo-sm">
            <img src="/assets/images/logo.png" alt="" height="25">
        </span>
    </a>

    <div class="h-100 mt-3" id="leftside-menu-container" data-simplebar>

        <ul class="side-nav">

            <li class="side-nav-item">
                <a href="/" class="side-nav-link">
                    <i class="uil-home-alt"></i>
                    <span> Halaman Utama </span>
                </a>
            </li>

            <li class="side-nav-title side-nav-item">MENU</li>

            <li class="side-nav-item">
                <a href="{{ route('balaks.index') }}" class="side-nav-link">
                    <i class="uil-trees"></i>
                    <span> Balak </span>
                </a>
            </li>

            <li class="side-nav-item">
                <a href="{{ route('pembelis.index') }}" class="side-nav-link">
                    <i class="uil-users-alt"></i>
                    <span> Pembeli </span>
                </a>
            </li>

            <li class="side-nav-item">
                <a href="{{ route('resits.index') }}" class="side-nav-link">
                    <i class="uil-receipt"></i>
                    <span> Resit </span>
                </a>
            </li>

            <li class="side-nav-item">
                <a href="{{ route('transaksis.index') }}" class="side-nav-link">
                    <i class="mdi mdi-cart"></i>
                    <span> Transaksi </span>
                </a>
            </li>

            <li class="side-nav-item">
                <a href="{{ route('loris.index') }}" class="side-nav-link">
                    <i class="mdi mdi-truck"></i>
                    <span> Lori </span>
                </a>
            </li>

            <li class="side-nav-item">
                <a href="{{ route('kawasans.index') }}" class="side-nav-link">
                    <i class="mdi mdi-map"></i>
                    <span> Kawasan </span>
                </a>
            </li>

            <li class="side-nav-title side-nav-item">TINDAKAN</li>

            <li class="side-nav-item">
                <a href="{{ route('transaksis.create') }}" class="side-nav-link">
                    <i class="mdi mdi-cart-plus"></i>
                    <span> Buat Pembelian </span>
                </a>
            </li>


            <div class="clearfix"></div>

    </div>
</div>
