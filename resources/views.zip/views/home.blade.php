@extends('layouts.app')
@section('title', 'Dashboard')
@section('content')
    <div class="container-fluid">
        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif
        <div class="row">
            {{-- <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <form class="d-flex">
                            <div class="input-group">
                                <input type="text" class="form-control form-control-light" id="dash-daterange">
                                <span class="input-group-text bg-primary border-primary text-white">
                                    <i class="mdi mdi-calendar-range font-13"></i>
                                </span>
                            </div>
                            <a href="javascript: void(0);" class="btn btn-primary ms-2">
                                <i class="mdi mdi-autorenew"></i>
                            </a>
                            <a href="javascript: void(0);" class="btn btn-primary ms-1">
                                <i class="mdi mdi-filter-variant"></i>
                            </a>
                        </form>
                    </div>
                    <h4 class="page-title">SISTEM PENGURUSAN PEMBALAKAN & LIGA SEPAKAT</h4>
                </div>
            </div> --}}




            <div class="col-12 mt-3">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="row">
                            <div class="col-12 mb-4 d-flex align-items-center justify-content-between">
                                <h4 class="header-title mb-0">Maklumat Data</h4>
                                <form id="dashboard-date-form" class="d-flex align-items-center">
                                    <label for="dashboard-date" class="me-2 mb-0">Tarikh:</label>
                                    <input type="date" id="dashboard-date" name="dashboard_date" class="form-control"
                                        value="{{ request('dashboard_date', now()->format('Y-m-d')) }}">
                                </form>
                            </div>
                            <div class="col-12 col-md-4 mb-4">
                                <div class="card h-100 shadow border-0"
                                    style="background: linear-gradient(135deg, #8fd6ff 0%, #3a7bd5 100%); border-radius:1.5rem;">
                                    <div
                                        class="card-body d-flex flex-column align-items-center justify-content-center text-white position-relative p-4">
                                        <div class="bg-white d-flex align-items-center justify-content-center mb-3 shadow"
                                            style="width:64px;height:64px;border-radius:50%;box-shadow:0 4px 24px rgba(58,123,213,0.2);">
                                            <i class="uil uil-users-alt" style="font-size:2rem;color:#3a7bd5;"></i>
                                        </div>
                                        <div class="fw-bold mb-1" style="font-size:2.3rem;">
                                            {{ \App\Models\Pembeli::when(request('dashboard_date'), function ($q) {return $q->whereDate('created_at', request('dashboard_date'));})->count() }}
                                        </div>
                                        <div class="text-white" style="font-size:1.1rem;">Jumlah Pembeli</div>
                                        <div class="position-absolute"
                                            style="right:10px;bottom:10px;opacity:0.07;font-size:4rem;">
                                            <i class="uil uil-users-alt"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-4 mb-4">
                                <div class="card h-100 shadow border-0"
                                    style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); border-radius:1.5rem;">
                                    <div
                                        class="card-body d-flex flex-column align-items-center justify-content-center text-white position-relative p-4">
                                        <div class="bg-white d-flex align-items-center justify-content-center mb-3 shadow"
                                            style="width:64px;height:64px;border-radius:50%;box-shadow:0 4px 24px rgba(67,233,123,0.2);">
                                            <i class="uil uil-trees" style="font-size:2rem;color:#43e97b;"></i>
                                        </div>
                                        <div class="fw-bold mb-1" style="font-size:2.3rem;">
                                            {{ \App\Models\Balak::when(request('dashboard_date'), function ($q) {return $q->whereDate('created_at', request('dashboard_date'));})->count() }}
                                        </div>
                                        <div class="text-white" style="font-size:1.1rem;">Jumlah Balak</div>
                                        <div class="position-absolute"
                                            style="right:10px;bottom:10px;opacity:0.07;font-size:4rem;">
                                            <i class="uil uil-trees"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-4 mb-4">
                                <div class="card h-100 shadow border-0"
                                    style="background: linear-gradient(135deg, #f7971e 0%, #ffd200 100%); border-radius:1.5rem;">
                                    <div
                                        class="card-body d-flex flex-column align-items-center justify-content-center text-white position-relative p-4">
                                        <div class="bg-white d-flex align-items-center justify-content-center mb-3 shadow"
                                            style="width:64px;height:64px;border-radius:50%;box-shadow:0 4px 24px rgba(247,151,30,0.2);">
                                            <i class="uil uil-exchange" style="font-size:2rem;color:#f7971e;"></i>
                                        </div>
                                        <div class="fw-bold mb-1" style="font-size:2.3rem;">
                                            {{ \App\Models\Transaksi::when(request('dashboard_date'), function ($q) {return $q->whereDate('created_at', request('dashboard_date'));})->count() }}
                                        </div>
                                        <div class="text-white" style="font-size:1.1rem;">Jumlah Transaksi</div>
                                        <div class="position-absolute"
                                            style="right:10px;bottom:10px;opacity:0.07;font-size:4rem;">
                                            <i class="uil uil-exchange"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title mb-4">Percent Balak Dijual</h4>
                                <div dir="ltr">
                                    <div id="gradient-chart" class="apex-charts" data-colors="#8f75da,#727cf5"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title mb-4">Jumlah Balak Terjual</h4>
                        <div dir="ltr">
                            <div id="line-chart" class="apex-charts" data-colors="#ffbc00"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="/assets/js/vendor/apexcharts.min.js"></script>
    <script>
        // Update the date input value when the form is submitted
        document.getElementById('dashboard-date').addEventListener('change', function() {
            const selectedDate = this.value;
            const url = new URL(window.location.href);
            url.searchParams.set('dashboard_date', selectedDate);
            window.location.href = url.toString();
        });
        $(document).ready(function() {
            var options = {
                chart: {
                    height: 350,
                    type: 'line',
                    zoom: {
                        enabled: false
                    },
                },
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    curve: 'smooth'
                },
                series: [{
                    name: "Jumlah Balak Terjual",
                    data: [
                        @php
                            use App\Models\Transaksi;
                            $data = [];
                            for ($i = 6; $i >= 0; $i--) {
                                $date = \Carbon\Carbon::now()->subDays($i)->format('Y-m-d');
                                $count = Transaksi::whereDate('tarikh_dibeli', $date)->count();
                                $data[] = $count;
                            }
                            echo implode(',', $data);
                        @endphp
                    ]
                }],
                xaxis: {
                    categories: [
                        @php
                            $dates = [];
                            for ($i = 6; $i >= 0; $i--) {
                                $dates[] = \Carbon\Carbon::now()->subDays($i)->format('d M Y');
                            }
                            echo "'" . implode("','", $dates) . "'";
                        @endphp
                    ],
                },
                tooltip: {
                    y: {
                        formatter: function(val) {
                            return val + " unit";
                        }
                    }
                }
            }

            var chart = new ApexCharts(document.querySelector("#line-chart"), options);
            chart.render();

            @php
                use App\Models\Balak;
                $total = Balak::count();
                $rosak = Balak::where('status', 'Dijual')->count();
                $percent = $total > 0 ? round(($rosak / $total) * 100, 2) : 0;
            @endphp

            var dataColors = $("#gradient-chart").data("colors");
            var colors = dataColors ? dataColors.split(",") : [];

            var options = {
                chart: {
                    height: 330,
                    type: "radialBar",
                    toolbar: {
                        show: true
                    }
                },
                plotOptions: {
                    radialBar: {
                        startAngle: -135,
                        endAngle: 225,
                        hollow: {
                            margin: 0,
                            size: "70%",
                            background: "#fff",
                            image: undefined,
                            imageOffsetX: 0,
                            imageOffsetY: 0,
                            position: "front",
                            dropShadow: {
                                enabled: true,
                                top: 3,
                                left: 0,
                                blur: 4,
                                opacity: 0.24
                            },
                        },
                        track: {
                            background: "#fff",
                            strokeWidth: "67%",
                            margin: 0,
                            dropShadow: {
                                enabled: true,
                                top: -3,
                                left: 0,
                                blur: 4,
                                opacity: 0.35
                            },
                        },
                        dataLabels: {
                            showOn: "always",
                            name: {
                                offsetY: -10,
                                show: true,
                                color: "#888",
                                fontSize: "17px"
                            },
                            value: {
                                formatter: function(o) {
                                    return parseInt(o) + " %";
                                },
                                color: "#111",
                                fontSize: "36px",
                                show: true,
                            },
                        },
                    },
                },
                fill: {
                    type: "gradient",
                    gradient: {
                        shade: "dark",
                        type: "horizontal",
                        shadeIntensity: 0.5,
                        gradientToColors: colors,
                        inverseColors: true,
                        opacityFrom: 1,
                        opacityTo: 1,
                        stops: [0, 100],
                    },
                },
                series: [{{ $percent }}],
                stroke: {
                    lineCap: "round"
                },
                labels: ["Dijual"],
            };

            var gradientChart = new ApexCharts(
                document.querySelector("#gradient-chart"),
                options
            );
            gradientChart.render();
        });
    </script>
@endsection
