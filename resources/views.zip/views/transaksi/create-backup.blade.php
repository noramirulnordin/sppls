<td>
    <select class="form-select" onchange="updateItem(${item.id}, this.value)" required>
        <option value="">Pilih Lori</option>
        @foreach ($loris as $lori)
            <option value="{{ $lori->id }}">{{ $lori->nama }} ({{ $lori->no_pendaftaran }})</option>
        @endforeach
    </select>
</td>


<script>
    function updateItem(id, loriId) {
        const itemIndex = cart.findIndex(item => item.id === id);
        if (itemIndex !== -1) {
            cart[itemIndex] = {
                ...cart[itemIndex],
                lori_id: loriId
            };
        }
    }
</script>
